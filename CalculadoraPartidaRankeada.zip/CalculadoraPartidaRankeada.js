function calcularNivel(vitorias, derrotas) {
    let saldoVitorias = vitorias - derrotas;
    let nivel;
    if(vitorias < 10) {
        nivel = "Ferro";
    } else if(vitorias >= 11 && vitorias <= 20) {
        nivel = "Bronze";
    } else if(vitorias >= 21 && vitorias <= 50) {
        nivel = "Prata";
    } else if(vitorias >= 51 && vitorias <= 80) {
        nivel = "Ouro";
    } else if(vitorias >= 81 && vitorias <= 90) {
        nivel = "Diamante";
    } else if(vitorias >= 91 && vitorias <= 100) {
        nivel = "Lendário";
    } else if(vitorias >= 101) {
        nivel = "Imortal";
    }

    return {saldoVitorias, nivel};
}

let resultados = [
    {vitorias: 5, derrotas: 2},
    {vitorias: 15, derrotas: 5},
    {vitorias: 30, derrotas: 10},
    {vitorias: 60, derrotas: 20},
    {vitorias: 85, derrotas: 30},
    {vitorias: 95, derrotas: 50},
    {vitorias: 105, derrotas: 70}
];

for (let i = 0; i < resultados.length; i++) {
    let vitorias = resultados[i].vitorias;
    let derrotas = resultados[i].derrotas;
    let resultado = calcularNivel(vitorias, derrotas);
    console.log(`Para ${vitorias} vitórias e ${derrotas} derrotas:`);
    console.log(`O Herói tem saldo de ${resultado.saldoVitorias} e está no nível de ${resultado.nivel}`);
}